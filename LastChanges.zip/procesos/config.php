<?php 
$config = array();
$config['servidor']='localhost';
$config['base_datos']='marketdb';
$config['usuario']='root';
$config['password']='';
/*
000WEBHOSTING
---------------------
servidor:mysql9.000webhost.com
base de datos:a9768316_ltdle
usuario:a9768316_root
password:titan121

	$config['servidor'] = 'localhost';
	$config['base_datos'] = 'marketdb';
	$config['usuario'] = 'root';
	$config['password'] = '';
*/
?>