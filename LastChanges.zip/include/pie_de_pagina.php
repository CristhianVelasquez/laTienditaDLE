<footer>
   <div id="mapa-nav">
      <div class="centradoFooter">
         <div class="mapa-nav-cont">
            <h1><a href="index.php">Home</a></h1>
         </div>
         <div class="mapa-nav-cont">
            <h2>Productos</h2>
            <ul>
               <li class=""><a href="index.php?pag=products&subpag=Abarrotes">Abarrotes</a></li>
               <li class=""><a href="index.php?pag=products&subpag=Bebidas">Bebidas</a></li>
               <li class=""><a href="index.php?pag=products&subpag=Cuidado%20personal">Cuidado personal</a></li>
               <li class=""><a href="index.php?pag=products&subpag=Desayuno">Desayuno</a></li>
               <li class=""><a href="index.php?pag=products&subpag=Embutidos">Embutidos</a></li>
               <li class=""><a href="index.php?pag=products&subpag=Enlatados">Enlatados</a></li>
               <li class=""><a href="index.php?pag=products&subpag=Galletas%20y%20golosinas">Galletas y Golosinas</a></li>
               <li class=""><a href="index.php?pag=products&subpag=Licores">Licores</a></li>
               <li class=""><a href="index.php?pag=products&subpag=Limpieza">Limpieza</a></li>
               <li class=""><a href="index.php?pag=products&subpag=Snacks%20y%20Piqueos">Snacks y Piqueos</a></li>
            </ul>
         </div>
         <div class="mapa-nav-cont">
            <h2>Ayuda</h2>
            <ul>
               <li><a href="index.php?pag=help" >Beneficios</a></li>
               <li><a href="index.php?pag=help" >Comprar</a></li>
               <li><a href="index.php?pag=help" >Formas de Pago</a></li>
               <li><a href="index.php?pag=help" >Registro</a></li>
               <li><a href="index.php?pag=help" >Preguntas Frecuentas</a></li>
			   <li><a href="index.php?pag=infoLegal" >Informaci&oacute;n legal</a></li>
			   
            </ul>
         </div>
         <div class="mapa-nav-cont">
            <h2>Registrar/Acceder</h2>
            <ul>
               <li><a href="index.php?pag=acceder" >Log in </a></li>
            </ul>
         </div>
         <div class="mapa-nav-cont">
            <h2>Carrito</h2>
            <ul>
               <li><a href="index.php?pag=car" >Ver carrito</a></li>
               <li><a href="#" >Comprar</a></li>
            </ul>
         </div>
         <div class="mapa-nav-cont">
            <h2>Empresa</h2>
            <ul>
               <li><a href="index.php?pag=nosotros" >Nosotros</a></li>
               <li><a href="index.php?pag=contactenos" >Contactenos</a></li>
            </ul>
         </div>
      </div>
   </div>
</footer>