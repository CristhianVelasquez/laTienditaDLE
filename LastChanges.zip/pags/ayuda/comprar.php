<div  class="tabbable tabs-left">
	<!--Sub Secciones*/-->
	<ul class="span6 nav nav-tabs" id="myTab">
		<li class="active"><a href="#P1" data-toggle="tab">¿Cómo comprar?</a></li>
		<li class=""><a href="#P2" data-toggle="tab">¿Existe un monto mínimo de compra?</a></li>
		<li class=""><a href="#P3" data-toggle="tab">¿Aceptan devoluciones?</a></li>
		<li class=""><a href="#P4" data-toggle="tab">¿Qué pasa si mi pedido no llega en la fecha establecida?</a></li>
		<li class=""><a href="#P5" data-toggle="tab">¿La empresa responderá ante posibles problemas en el recibo de mi compra?</a></li>
		<li class=""><a href="#P6" data-toggle="tab">He cambiado algún dato sobre mi empresa ¿Afectará mis comrpas?</a></li>
	</ul>
	<!--Respuestas*/-->
	<div class="tab-content">
		<div class="tab-pane active" id="P1">
			<p>Debe elegir el producto que desee, y luego darle clic en añadir a carrito de compras.</br> 
			Después le pediremos que coloque la cantidad que requiere de dicho producto y podrá 
			ver el registro de los productos en su carrito .Para finalizar deberá seleccionar la forma de 
			pago y concluir la operación.</p>
		</div>
		<div class="tab-pane" id="P2">
			<p>Sí, la suma total de su pedido debe ser mayor o igual a 100 nuevos soles.</p>
		</div>
		<div class="tab-pane" id="P3">
			<p>Solo si algún producto dentro de su compra esta vencido, se aceptaran devoluciones.</br>
			Por otro lado, el cliente debe verificar la conformidad de la entrega de su pedido después de 
			que uno de nuestros colaboradores lo entregue.</p>
		</div>
		<div class="tab-pane" id="P4">
			<p>Esto no ocurrirá, ya que la programación de entrega de pedidos será previamente 
			evaluada para que no ocurra ningún inconveniente de este tipo.</p>
		</div>
		<div class="tab-pane" id="P5">
			<p>Si ocurre algún error al enviar su compra, lo cual procuraremos no se dé, La tiendita de la 
			esquina correrá con los gastos ocasionados por este percance.</p>
		</div>
		<div class="tab-pane" id="P6">
			<p>En este caso, deberá actualizar los o el dato que haya sido cambiado en la sección de 
			actualizar datos una vez haya iniciado sesión.</p>
		</div>
	</div>
</div>