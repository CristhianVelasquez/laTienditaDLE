<div  class="tabbable tabs-left">
	<!--Sub Secciones*/-->
	<ul class="nav nav-tabs" id="myTab">
		<li class="active"><a href="#P1" data-toggle="tab">¿Tienen personal calificado?</a></li>
		<li class=""><a href="#P2" data-toggle="tab">¿Brindan beneficios hacia los clientes?</a></li>
		<li class=""><a href="#P3" data-toggle="tab">¿Sus precios son mejores que la competencia?</a></li>
		<li class=""><a href="#P4" data-toggle="tab">¿Como es su servicio de reparto?</a></li>
		<li class=""><a href="#P5" data-toggle="tab">¿Ofrecen diversidad de marcas?</a></li>
		<li class=""><a href="#P6" data-toggle="tab">¿Tienen una sección de acopio?</a></li>
	</ul>
	<!--Respuestas*/-->
	<div class="tab-content">
		<div class="tab-pane active" id="P1">
			<p>1. Contamos con un staff de profesionales altamente calificados, egresados 
			de las mejores universidades de nuestro país, para la supervisión de cada área de nuestra empresa.</p>
		</div>
		<div class="tab-pane" id="P2">
			<p>2. Si, ahorro de tiempo para nuestros clientes, ya que facilitamos la compra y entrega de todos los productos en sus locales,
			para un abastecimiento oportuno y completo que se necesita para la satisfacción del cliente.</p>
		</div>
		<div class="tab-pane" id="P3">
			<p>3. Ofrecemos los mejores precios que hay en el mercado para obtener la fidelidad  y lealtad del cliente.</p>
		</div>
		<div class="tab-pane" id="P4">
			<p>4. Contamos con un sistema de reparto optimizado para nuestro rubro, ya que sabemos cuán importante es la puntualidad 
			con la entrega de la mercadería para el cliente. </p>
		</div>
		<div class="tab-pane" id="P5">
			<p>5. Ofrecemos la mayor variedad de marcas en cada categoría de compra para que el cliente escoja la opción que más le favorece.</p>
		</div>
		<div class="tab-pane" id="P6">
			<p>6.	Brindamos instalaciones para el acopio de productos con la mayor organización que hay en el mercado para que los productos 
			siempre estén en óptimas condiciones.</p>
		</div>
	</div>
</div>