<h1 class="title-pags">Contacto</h1>
<p class="text-justified espaciar-texto">Las sugerencias o inconveniente pueden ser enviadas a trav&eacute;s del siguiente formulario, donde  gustosos los atenderemos.</p>
<div class='widget ContactForm' id='ContactForm1'>
	<div class='contact-form-widget'>
		<div class='form'>
			<form action="" name='contact-form' method="POST">
				<p class="labelFormularioContacto">Nombre<span class="alertaForm">(*)</span></p>
				
				<input class='contact-form-name' id='Contactos_name' name='nombre' size='30' type='text' value='' maxlength="100"/> <p id="nombreError"></p>
				
				<p class="labelFormularioContacto">Correo electr&oacute;nico <span class="alertaForm">(*)</span></p>
				
				<input class='contact-form-email' id='Contacto_mail' name='correo' size='30' type='email' value='' maxlength="100" /> <p id="correoError"></p>
				
				<p class="labelFormularioContacto">Mensaje <span class="alertaForm">(*)</span></p>
				
				<textarea class='contact-form-email-message' cols='25' id='Contacto_mensaje' name='mensaje' rows='5' maxlength="300"></textarea> <p id="mensajeError"></p>
				
				<input class='contact-form-button contact-form-button-submit' id='BotonContactenos' type='submit' value='Enviar'/>
				
		  </form>
		</div>
	</div>
</div>
