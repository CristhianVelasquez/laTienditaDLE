<div id="registroFinal">
<h1>Antes de empezar a comprar</h1>
	<form id="registroFinal-datosContacto" action="" method="">
		<fieldset>
			<legend>Datos de Contacto</legend>
			<label>Correo electrónico:</label>
			<input type="email" name="email"/><br/>
			<label>Numero de teléfono</label>
			<input type="text" name="telefono"/>
		</fieldset>
		
		<input type="checkbox" name="contactoViaEmail" value="">Deseo que La Tiendita de la Esquina pueda contactarse vía correo electrónico<br>
		<button>Volver</button>
		<button>Finalizar</button>
	</form>

</div>